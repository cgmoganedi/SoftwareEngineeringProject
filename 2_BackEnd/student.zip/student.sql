-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 17, 2018 at 09:12 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student`
--

-- --------------------------------------------------------

--
-- Table structure for table `achievement`
--

CREATE TABLE `achievement` (
  `Achievement_Title` text NOT NULL,
  `Description` text NOT NULL,
  `Date_Obtained` date NOT NULL,
  `Identity_Number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `education`
--

CREATE TABLE `education` (
  `Institution` varchar(225) NOT NULL,
  `Qualification_Name` varchar(225) NOT NULL,
  `Qualification Field` varchar(225) NOT NULL,
  `Majors` varchar(225) NOT NULL,
  `Start_Date` date NOT NULL,
  `Completion_Date` date NOT NULL,
  `Academic_Average` decimal(65,0) NOT NULL,
  `Grade_Scale` varchar(225) NOT NULL,
  `Identity_Number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `experience`
--

CREATE TABLE `experience` (
  `Organisation` varchar(225) NOT NULL,
  `Location` varchar(225) NOT NULL,
  `Position` varchar(225) NOT NULL,
  `Start_Date` date NOT NULL,
  `End_Date` date NOT NULL,
  `Type_Of_Involvement` varchar(225) NOT NULL,
  `Responsibilities` text NOT NULL,
  `Identity_Number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `interests`
--

CREATE TABLE `interests` (
  `Interests` varchar(225) NOT NULL,
  `Non-Academic_Qualifications` varchar(225) NOT NULL,
  `Clubs&Societies` varchar(225) NOT NULL,
  `Identity_Number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `Username` text NOT NULL,
  `Email_Address` varchar(225) NOT NULL,
  `Password` varchar(225) NOT NULL,
  `ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`Username`, `Email_Address`, `Password`, `ID`) VALUES
('taiman', 'taiman@gmail.com', 'taiman', 1),
('jomo', 'jomo@gmail.com', '12345', 2),
('engine', 'engine@gmail.com', 'engine', 3),
('engine', 'engine@gmail.com', 'enginethis', 4),
('mara', 'mara@gmail.com', '12345', 7),
('lovemore', 'lovemore@gmail.com', 'lovemore', 8);

-- --------------------------------------------------------

--
-- Table structure for table `personal bio`
--

CREATE TABLE `personal bio` (
  `Introduce_Yourself` text NOT NULL,
  `Identity_Number` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal bio`
--

INSERT INTO `personal bio` (`Introduce_Yourself`, `Identity_Number`) VALUES
('My name is Jomo, people who know me call me mjomane. I\'m a student for software engineering course at Wits. Ngiyavithiza angidlali. Welele', 0);

-- --------------------------------------------------------

--
-- Table structure for table `personal information`
--

CREATE TABLE `personal information` (
  `Title` varchar(225) NOT NULL,
  `Name` varchar(225) NOT NULL,
  `Surname` varchar(225) NOT NULL,
  `Location` varchar(225) NOT NULL,
  `Date_Of_Birth` date NOT NULL,
  `Identity_Number` int(13) NOT NULL,
  `Email_Address` varchar(225) NOT NULL,
  `Cellphone_Number` int(225) NOT NULL,
  `Marital_Status` varchar(225) NOT NULL,
  `Gender` varchar(225) NOT NULL,
  `Ethnicity` varchar(225) NOT NULL,
  `Home_Address` varchar(225) NOT NULL,
  `Postal_Code` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `Skills` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

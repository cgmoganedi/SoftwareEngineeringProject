<?php
namespace wapmorgan\MediaFile\Exceptions;

class Exception extends \Exception {}

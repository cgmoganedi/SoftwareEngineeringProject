<?php
namespace wapmorgan\MediaFile\Exceptions;

class ParsingException extends Exception {}

<?php
namespace wapmorgan\MediaFile\Exceptions;

class FileAccessException extends Exception {}

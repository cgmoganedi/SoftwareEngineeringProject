<?php
$db = 'jobmatch';
$server = 'localhost';
$dbUser = 'root';
$dbPass = '';
$output = array();

$conn = mysqli_connect($server,$dbUser,$dbPass,$db);
<?php

$user = $_POST['username'];
$pass = $_POST['password'];
$db = 'student';
$server = 'localhost';
$dbUser = 'root';
$dbPass = '';
$output = array();

$conn = mysqli_connect($server,$dbUser,$dbPass,$db);

if(!$conn)
{
    echo "Error! ".mysqli_error($conn);
}
else
{
    $sql = "SELECT * FROM login WHERE Username = '$user' AND Password = '$pass'";
    $result = mysqli_query($conn, $sql);
	
	
    if(!$result)
    {
        echo 'Error on making the query';
    }
    else
    {	
        while($row = $result->fetch_assoc())
        {
            $output[] = $row;
			echo "Welcome ".$row["Username"]." ".$row["Password"];
			header('Location: /github/student-profile.html');
        }
        if(sizeof($output) == 1)
        {
            session_start();
            $_SESSION['UserID'] = $output[0]['ID'];
        }
        elseif (sizeof($output) == 0)
        {
            echo "<p> Wrong password or username </p>";
        }
        else
        {
            echo "<p> Duplicates </p>";
        }
    }

}

$conn->close();
?>
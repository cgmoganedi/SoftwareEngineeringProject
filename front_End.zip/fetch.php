<?php
include_once('connection.php');
$query="select * from student";
$result=mysql_quesry($query);
?>

<!DOCTYPE html>
<html>
	<title>
		<head>Fetch Data From Database</head>
		</title>
<body>

	<table align="center" border="1px" style="width:600px; line-height:40px">
		<tr>
			<th colspan="4"><h2>Student Record</h2></th>
		</tr>
		<t>
			<th>ID</th>
			<th>Username</th>
			<th>Email</th>
			<th>Password</th>
		</t>
		<?php 
        while($rows=mysql_fetch_assoc($result))
        {
    ?>        
            <tr>
                <td><?php echo $rows['ID']; ?></td>
                <td><?php echo $rows['Username']; ?></td>
                <td><?php echo $rows['Email']; ?></td>
                <td><?php echo $rows['Password']; ?></td>
            </tr>
    <?php     
        }
    ?>    
    </table>
    
</body>
</html>
<?php
/**
 * Created by PhpStorm.
 * User: thabang
 * Date: 2017/04/22
 * Time: 9:09 PM
 */

/*session_start();
$UserID = $_SESSION['UserID'];

$_SESSION["ID_num"] = $ID;
echo $_SESSION["ID_num"];*/

$Title = $_POST['Title'];
$Name = $_POST['Name'];
$Surname = $_POST['Surname'];
$Location = $_POST['Location'];
$DOB = $_POST['Date_Of_Birth'];
$ID = $_POST['Identity_Number'];
$email = $_POST['Email'];
$Cell = $_POST['Cellphone_Number'];
$MaritalStatus = $_POST['Marital_Status'];
$Gender = $_POST['Gender'];
$Ethnicity = $_POST['Ethnicity'];
$PostalCode = $_POST['Postal_Code'];
$HomeAddress = $_POST['Home_Address'];
$output = array();

$user = 'root';
$pass = '';
$server = 'localhost';
$database = 'student';

$conn = mysqli_connect($server,$user,$pass,$database);
if(!$conn)
{
    die("Connection failed: ".mysqli_connect_error());
}

$sql = "INSERT INTO personal information(Title,Name,Surname,Location,Date_of_Birth,Identity_Number,Email_Address,Cellphone_Number,Marital_Status,Gender,Ethnicity,Home_Address,Postal_Code) VALUES('$Title','$Name','$Surname','$Location','$DOB','$ID','$email','$Cell','$MaritalStatus','$Gender','$Ethnicity','$HomeAddress','$PostalCode')";

if($conn->query($sql) === TRUE)
{
    echo "Succesfully uploaded!";
}
else
{
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
